
package prog6112ea2020q3;
import java.io.*;


/**
 *
 * @author lindelo Desiree Nkosi
 */
public class PROG6112Ea2020Q3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
       
    }
    
}
